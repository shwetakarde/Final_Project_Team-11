import { Component, OnInit } from '@angular/core';
import{ ContactUs } from '../contact-us';
@Component({
  selector: 'app-indexpage',
  templateUrl: './indexpage.component.html',
  styleUrls: ['./indexpage.component.css']
})
export class IndexpageComponent implements OnInit {

  constructor() { }
  ngOnInit(): void {
  }
  //contactModel = new ContactUs('','');
  contactmodel = new ContactUs('','');
}
