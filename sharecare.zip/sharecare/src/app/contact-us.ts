export class ContactUs {
    constructor(
        public email:string,
        public message:string
    ){}
}
