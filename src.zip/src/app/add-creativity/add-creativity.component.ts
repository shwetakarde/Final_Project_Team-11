import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-creativity',
  templateUrl: './add-creativity.component.html',
  styleUrls: ['./add-creativity.component.css']
})
export class AddCreativityComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
