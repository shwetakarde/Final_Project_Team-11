import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contactuslist',
  templateUrl: './contactuslist.component.html',
  styleUrls: ['./contactuslist.component.css']
})
export class ContactuslistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
