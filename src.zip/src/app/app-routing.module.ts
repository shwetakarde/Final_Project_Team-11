import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { UploadBookComponent } from './upload-book/upload-book.component';
import { DonationComponent } from './donation/donation.component';
import { AddCreativityComponent } from './add-creativity/add-creativity.component';
import { ArtisticBlockComponent } from './artistic-block/artistic-block.component';
import { CartComponent } from './cart/cart.component';
import { MyProfileComponent } from './my-profile/my-profile.component';
import { ShopbookComponent } from './shopbook/shopbook.component';


const routes: Routes = [
  {path:'',pathMatch: 'full',redirectTo:'/Home'},
  {path:'Home',component:HomeComponent},
  {path:'UploadBook',component:UploadBookComponent},
  {path:'Donation',component:DonationComponent},
  {path:'AddCreativity',component:AddCreativityComponent},
  {path:'ArtisticBlock',component:ArtisticBlockComponent},
  {path:'Cart',component:CartComponent},
  {path:'MyProfile',component:MyProfileComponent},
  {path: 'shop', component: ShopbookComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
