import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegistrationComponent } from './registration/registration.component';
import { LoginComponent } from './login/login.component';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { HomepageComponent } from './homepage/homepage.component';
import { IndexpageComponent } from './indexpage/indexpage.component';

import { AdminhomepageComponent } from './adminhomepage/adminhomepage.component';
import { UserlistComponent } from './adminhomepage/userlist/userlist.component';
import { BooklistComponent } from './adminhomepage/booklist/booklist.component';
import { ContactuslistComponent} from './adminhomepage/contactuslist/contactuslist.component';
import { UpdatebookComponent } from './homepage/updatebook/updatebook.component';
import { CreativityComponent } from './homepage/creativity/creativity.component';
import { CreativitygalleryComponent } from './homepage/creativitygallery/creativitygallery.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { InnerheaderComponent } from './innerheader/innerheader.component';

import { DonationlistComponent } from './adminhomepage/donationlist/donationlist.component';
import { OrderlistComponent } from './adminhomepage/orderlist/orderlist.component';

//import { UploadbookComponent } from './homepage/uploadbook/uploadbook.component';

@NgModule({
  declarations: [
    AppComponent,
    RegistrationComponent,
    LoginComponent,
    HomepageComponent,
    IndexpageComponent,
    
    AdminhomepageComponent,
    UserlistComponent,
    BooklistComponent,
   ContactuslistComponent,
    UpdatebookComponent,
    CreativityComponent,
    CreativitygalleryComponent,
    HeaderComponent,
    FooterComponent,
    InnerheaderComponent,
    
    DonationlistComponent,
    OrderlistComponent,
    
    // UploadbookComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
