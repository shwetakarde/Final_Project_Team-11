import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-artistic-block',
  templateUrl: './artistic-block.component.html',
  styleUrls: ['./artistic-block.component.css']
})
export class ArtisticBlockComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
