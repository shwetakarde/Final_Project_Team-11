import { stringify } from '@angular/compiler/src/util';
import { Artistic } from './artistic';

describe('Artistic', () => {
  it('should create an instance', () => {
    expect(new Artistic('')).toBeTruthy();
  });
});
