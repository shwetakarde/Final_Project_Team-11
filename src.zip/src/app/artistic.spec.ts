import { Artistic } from './artistic';

describe('Artistic', () => {
  it('should create an instance', () => {
    expect(new Artistic('')).toBeTruthy();
  });
});
