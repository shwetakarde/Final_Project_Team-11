export class Artistic {
    constructor(
        public email:string,
        public message:string
    ){}
}
