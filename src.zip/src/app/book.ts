export class Book {
    constructor(
        public BookTitle:string,
        public BookAuthor:string,
        public totalPages:number,
        public Category:string,
        public description:string
    ){}
}
