import { Component, OnInit } from '@angular/core';
import { Book } from '../book';
//import { HttpClient, HttpEventType } from '@angular/common/http';
//import { Book } from '../book';
@Component({
  selector: 'app-bookdetails',
  templateUrl: './bookdetails.component.html',
  styleUrls: ['./bookdetails.component.css']
})
export class BookdetailsComponent implements OnInit {
constructor(){}
  //constructor(private httpClient: HttpClient) { }
  // selectedFile: File;
  // base64Data: any;
  // msg: string;
  // imageName: any;
ngOnInit(): void {
  }
  // getValues(val: any)
  // {
  //   console.warn(val);
   //}
  Category = ['Fictional','Non-Fictional','Business & Economics','Biographies & Autobiographies'];
  bookmodel= new Book('','',0,'','');
}
