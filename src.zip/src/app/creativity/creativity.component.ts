import { Component, OnInit } from '@angular/core';
import { Artistic } from '../artistic';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ArtisticService } from '../artistic.service';
//import { Route } from '@angular/compiler/src/core';

@Component({
  selector: 'app-creativity',
  templateUrl: './creativity.component.html',
  styleUrls: ['./creativity.component.css']
})
export class CreativityComponent implements OnInit {
  msg='';
  constructor(private _service:ArtisticService, private _router: Router) { }

  ngOnInit(): void {
  }
  artisticModel = new Artistic('');
  addCreativityCreativity() {
    this._service.addCreativity(this.artisticModel).subscribe(
      data => {
        console.log("response received");
        this._router.navigate(['/login'])

      },
      error => {
        console.log("exception occured");
        this.msg = "Email already Exists";
      }

    )
 }
}
