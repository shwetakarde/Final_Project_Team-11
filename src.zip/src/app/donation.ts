export class Donation {
    constructor(
        public email:string,
        public date:string,
        public paymentMode:string,
        public amount:number
    ){}

}
