import { Component, OnInit } from '@angular/core';
import { Donation } from '../donation';
@Component({
  selector: 'app-donation',
  templateUrl: './donation.component.html',
  styleUrls: ['./donation.component.css']
})
export class DonationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  paymentMode = ['Net Banking','Debit Card','Credit Card'];
  donation= new Donation('','','',1000);

}
