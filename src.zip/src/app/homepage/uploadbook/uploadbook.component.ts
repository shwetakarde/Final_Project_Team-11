import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-uploadbook',
  templateUrl: './uploadbook.component.html',
  styleUrls: ['./uploadbook.component.css']
})
export class UploadbookComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
