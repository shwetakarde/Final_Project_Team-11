import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-innerheader',
  templateUrl: './innerheader.component.html',
  styleUrls: ['./innerheader.component.css']
})
export class InnerheaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
