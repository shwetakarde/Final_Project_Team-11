import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddCreativityComponent } from './add-creativity.component';

describe('AddCreativityComponent', () => {
  let component: AddCreativityComponent;
  let fixture: ComponentFixture<AddCreativityComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddCreativityComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddCreativityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
