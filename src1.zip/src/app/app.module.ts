import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { UploadBookComponent } from './upload-book/upload-book.component';
import { DonationComponent } from './donation/donation.component';
import { AddCreativityComponent } from './add-creativity/add-creativity.component';
import { ArtisticBlockComponent } from './artistic-block/artistic-block.component';
import { CartComponent } from './cart/cart.component';
import { MyProfileComponent } from './my-profile/my-profile.component';
import { ShopbookComponent } from './shopbook/shopbook.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    UploadBookComponent,
    DonationComponent,
    AddCreativityComponent,
    ArtisticBlockComponent,
    CartComponent,
    MyProfileComponent,
    ShopbookComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
