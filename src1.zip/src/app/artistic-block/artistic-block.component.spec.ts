import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ArtisticBlockComponent } from './artistic-block.component';

describe('ArtisticBlockComponent', () => {
  let component: ArtisticBlockComponent;
  let fixture: ComponentFixture<ArtisticBlockComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ArtisticBlockComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ArtisticBlockComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
