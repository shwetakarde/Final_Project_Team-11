import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shopbook',
  templateUrl: './shopbook.component.html',
  styleUrls: ['./shopbook.component.css']
})
export class ShopbookComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
