import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { User } from '../user';

@Component({
  selector: 'app-forgot',
  templateUrl: './forgot.component.html',
  styleUrls: ['./forgot.component.css']
})
export class ForgotComponent implements OnInit {
//   form = new FormGroup({
//   password: new FormControl('',Validators.required),
//   cnfPassword: new FormControl('',Validators.required)
// })

user:User=new User();
  constructor() { }

  ngOnInit(): void {
  }
  // confirm(user:User){
  //   if(user.password!=user.cnfPassword){
  //     alert("Password mismatch");
  //     // this.router.navigate(['signup']);
  //   }else{
  //     alert("fine");
  //   }
  // }

}
