import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

// import { NgForm } from '@angular/forms';
import { User } from '../user';


@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {
  // form = new FormGroup({
   
  //   emailAddress:new FormControl('',Validators.required),
  //   password: new FormControl('',Validators.required)
  // })
  user:User=new User();
  constructor() { }
  
  ngOnInit(): void {
  }
    
}



