import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from '../user';





@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  // form = new FormGroup({
  //   firstName: new FormControl('',Validators.required),
  //   lastName: new FormControl('',Validators.required),
  //   userName: new FormControl('',Validators.required),
  //   password: new FormControl('',Validators.required),
  //   cnfPassword: new FormControl('',Validators.required),
  //   mobNumber: new FormControl('',Validators.required),
  //   emailId:new FormControl('',Validators.required)

  // })
  user:User=new User();

  constructor(private router : Router) { }

  ngOnInit(): void {
  }


// register(user:User){
//   if(user.password!=user.cnfPassword){
//     alert("Password mismatch");
//     this.router.navigate(['signup']);
//   }else{
//     alert("fine");
//   }
// }

}
