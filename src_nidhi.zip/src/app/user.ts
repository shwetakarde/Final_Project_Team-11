export class User{

    
        public firstName:String;
        public lastName:String;
       
        public mobNumber:any;
        public emailId:String;
        public password:any;
        // public cnfPassword:any;
       
  
}